     // Main entry point for the ZooManager application.
    //@param args command-line arguments
    package zoo;

public class Main {
    public static void main(String[] args) {
        ZooManager manager = new ZooManager();
        boolean running = true;
        while (running) {
            manager.displayMenu();
            int choice = manager.getUserChoice();
            switch (choice) {
                case 1 -> manager.listAnimals();
                case 2 -> manager.moveAllAnimals();
                case 3 -> manager.listenToAllAnimals();
                case 4 -> {
                    running = false;
                    System.out.println("Exiting Zoo Manager. Goodbye!");
                }
            }
        }
        manager.closeScanner();
    }
}
