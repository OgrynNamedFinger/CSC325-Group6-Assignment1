package zoo;
// The concrete subclass for a BlueJay using the Animal abstract class and Flyable, Nesting interfaces


public class BlueJay extends Animal implements Flyable, Nesting {
private String name;
private int age;
private String species;

    // Constructor for Bird
    public BlueJay(String name, int age, String species) {
        this.name = name;
        this.age = age;
        this.species = species;
    }

    // Overrides the makeSound method from the Abstract Animal class
    @Override
    public void makeSound() {
        System.out.println(name + " says: \"Chirp, Chirp.\"");
    }

    // Overrides the move method from the Abstract Animal class
    @Override
    public void move() {
        System.out.println(name + " hops from branch to branch.");
    }

    // Overrides the fly method from the Flyable interface
    @Override
    public void fly() {
        System.out.println(name + " soars through the sky.");
    }

    // Overrides the buildNest method from the Nesting interface
    @Override
    public void buildNest() {
        System.out.println(name + " builds a nest in a tree.");
    }

    // Getter for name
    @Override
    public String getName() {
        return name;
    }
    
    // Getter for age
    @Override
    public int getAge() {
        return age;
    }

    // Getter for species
    @Override
    public String getSpecies() {
        return species;
    }

    // Setter for name
    @Override
    public void setName(String name) {
        this.name = name;
    }
    
    // Setter for age
    @Override
    public void setAge(int age) {
        this.age = age;
    }

    // Setter for species
    @Override
    public void setSpecies(String species) {
        this.species = species;
    }
}
