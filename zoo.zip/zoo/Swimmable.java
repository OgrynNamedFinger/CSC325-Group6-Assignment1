package zoo;
// Interface for swimming animals


public interface Swimmable {
    // The swimming method for all swimming animals
    public void swim();
}
