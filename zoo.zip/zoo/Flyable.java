package zoo;
// Interface for flying animals


public interface Flyable {
    
    //The flying method for all flying animals
    public void fly();
}
