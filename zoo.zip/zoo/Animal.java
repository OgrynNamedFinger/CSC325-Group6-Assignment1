package zoo;
// Abstract class Animal which represents all animals


public abstract class Animal {

    //The abstract method for making sound
    abstract public void makeSound();

    //The abstract method for moving
    abstract public void move();

    //Getters and setters for name and age
    abstract public String getName();
    abstract public int getAge();
    abstract public String getSpecies();
    abstract public void setName(String name);
    abstract public void setAge(int age);
    abstract public void setSpecies(String species);
}
    