package zoo;
// Interface for animals that can run


public interface Runnable {
    //The running method for all running animals
    public void run();
}
