package zoo;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

// Manages the zoo application, user interaction, and animal collection.

public class ZooManager {

    private final Scanner scanner;
    private final List<Animal> animals;

    // Constructs a ZooManager and loads animals into the collection.
    public ZooManager() {
        scanner = new Scanner(System.in);
        animals = new ArrayList<>();
        loadAnimals();
    }

     // Loads animals into the zoo's collection.
        private void loadAnimals() {
        animals.add(new BlueJay("Donnie", 2, "Blue Jay"));
        animals.add(new Wolf("Moxie", 3, "Wolf"));
        animals.add(new Trout("Macy", 1, "Trout"));
        // Add more animals as needed
    }

    // Displays the main menu options.
    public void displayMenu() {
        System.out.println("Welcome to the Zoo Manager!");
        System.out.println("1. List all Animals");
        System.out.println("2. Move all Animals");
        System.out.println("3. Listen to all Animals");
        System.out.println("4. Exit");
    }

     // Gets the user's menu choice with exception handling for invalid input.
     // @return the user's menu choice as an integer
    public int getUserChoice() {
        int choice = -1;
        while (true) {
            System.out.print("Enter your choice: ");
            try {
                choice = scanner.nextInt();
                if (choice >= 1 && choice <= 4) {
                    break;
                } else {
                    System.out.println("Please enter a number between 1 and 4.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.next(); // clear invalid input
            }
        }
        return choice;
    }

    // Lists all animals in the zoo.
    public void listAnimals() {
        System.out.println("Animals in the zoo:");
        for (Animal animal : animals) {
            System.out.println("- " + animal.getName() + " is a " + animal.getSpecies() + " aged " + animal.getAge() + " year(s).");
        }
    }

    //Makes all animals move.
    public void moveAllAnimals() {
        for (Animal animal : animals) {
            animal.move();
            if(animal instanceof Runnable runnable) {
                runnable.run();
            } 
            if(animal instanceof Swimmable swimmable) {
                swimmable.swim();
            } 
            if(animal instanceof Flyable flyable) {
                flyable.fly();
            } 
            if(animal instanceof Nesting nesting) {
                nesting.buildNest();
            }
        }
    }

    // Makes all animals produce their sound.
    public void listenToAllAnimals() {
        for (Animal animal : animals) {
            animal.makeSound();
        }
    }

    // Closes the scanner resource.
    public void closeScanner() {
        scanner.close();
    }
}