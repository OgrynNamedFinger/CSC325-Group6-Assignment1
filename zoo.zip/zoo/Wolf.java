package zoo;
// The concrete subclass for a Wolf using the Animal abstract class and Runnable, Nesting interfaces


public class Wolf extends Animal implements Runnable, Nesting{
private String name;
private int age;
private String species;

    // Constructor for Mammal
    public Wolf(String name, int age, String species) {
        this.name = name;
        this.age = age;
        this.species = species;
    }

    // Overrides the makeSound method from the Abstract Animal class
    @Override
    public void makeSound() {
        System.out.println(name + " says: \"Howl!\"");
    }

    // Overrides the move method from the Abstract Animal class
    @Override
    public void move() {
        System.out.println(name + " trods back and forth.");
    }

    // Overrides the run method from the Runnable interface
    @Override
    public void run() {
        System.out.println(name + " runs swiftly on all fours.");
    }

    // Overrides the buildNest method from the Nesting interface
    @Override
    public void buildNest() {
        System.out.println(name + " builds a den in the ground.");
    }

    // Getter for name 
    @Override
    public String getName() {
        return name;
    }
    
    // Getter for age
    @Override
    public int getAge() {
        return age;
    }

    // Getter for species
    @Override
    public String getSpecies() {
        return species;
    }

    // Setter for name
    @Override
    public void setName(String name) {
        this.name = name;
    }
    
    // Setter for age
    @Override
    public void setAge(int age) {
        this.age = age;
    }

    // Setter for species
    @Override
    public void setSpecies(String species) {
        this.species = species;
    }
}
