package zoo;
//Interface for making a home or nest


public interface Nesting {

    // The buildNest method for all nesting animals
    void buildNest();
}
